from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

TRANSLATE_API_URL = "https://libretranslate.com/translate"  # Use your preferred API
API_KEY = "your_api_key_here"  # Replace with your API key

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/translate', methods=['POST'])
def translate():
    data = request.json
    text = data.get('text')
    source_lang = data.get('source_lang')
    target_lang = data.get('target_lang')

    if not text or not source_lang or not target_lang:
        return jsonify({'error': 'Missing data'}), 400

    response = requests.post(TRANSLATE_API_URL, data={
        'q': text,
        'source': source_lang,
        'target': target_lang,
        'format': 'text',
        'api_key': API_KEY
    })

    if response.status_code == 200:
        return jsonify(response.json())
    else:
        return jsonify({'error': 'Translation failed'}), 500

if __name__ == '__main__':
    app.run(debug=True)
