# Bhargavterli Website
This website is designed for personal productivity, fitness tracking, and student success.
## Features:
- **Fitness Tracker**
- **Productivity Tools**
- **Study Timetable**
## How to Use:
1. Upload these files to a GitHub repository.
2. Enable GitHub Pages in Settings.
3. Your website will be live!